# File-Name:       clc_graphs_rep.R                                  
# Date:            2015-11-10                               
# Author:          Andrew Little                                       
# Purpose:         Replicates graphs that appear in "Coordination, Learning, and Coups", (JCR Forthcoming) 
# Data:            Coup data from Powell and Thyne, Regime Type from Geddes, Wright, and Frantz

rm(list=ls())

# Powell and Thyne Coup Data as of 3/2014
# http://www.jonathanmpowell.com/coup-detat-dataset.html
coup2 <- read.csv("powell_thyne_coups_final.txt", sep="\t")

coup2 <- subset(coup2, year < 2014)
check <- table(coup2$year)
coup2$year5 <- 5*floor(coup2$year/5)
coup2 <- coup2[order(coup2$year),]
table(coup2$year) - check

# Creating 5 year averages for coup attempts
coup5yr <- table(coup2$year5, coup2$coup)[,1 ] + table(coup2$year5, coup2$coup)[,2]
#adjusting 2010-2013 for fact that it only has 4 years
data5yr <- data.frame(year = unique(coup2$year5), total=coup5yr)
data5yr$success <- table(coup2$year5, coup2$coup)[,2]

data5yr$totalpy <- data5yr$total/5
data5yr$totalpy[data5yr$year == 2010] <- data5yr$totalpy[data5yr$year == 2010]*5/4
data5yr$successpy <- data5yr$success/5
data5yr$successpy[data5yr$year == 2010] <- data5yr$successpy[data5yr$year == 2010]*5/4



library(foreign)

# Importing GWF data 
# http://dictators.la.psu.edu/
gwf <- read.dta("GWFtscs.dta")
gwf <- subset(gwf, year >= 1950)
# Variable for any military component (solid line in figure)
gwf$anymil <- regexpr("military", gwf$gwf_regimetype)>0

byyear <- data.frame(table(gwf$year))
names(byyear) <- c("year", "obs")

byyear$primarymil <- table(gwf$year, gwf$gwf_military)[,2]
byyear$anymil <- table(gwf$year, gwf$anymil)[,2]

###########################
# START CODE FOR FIGURE 1
###########################
par(mfrow=c(1,2), mar=c(3,3,1,1), mgp=c(2, .7, 0))
plot(as.numeric(dimnames(table(gwf$anymil, gwf$year))[[2]]), 
     table(gwf$anymil, gwf$year)[2,], type="l", 
     ylim=c(0, max(table(gwf$anymil, gwf$year)[2,])),
     xlab="Year",
     ylab="Count of Military Regimes", axes=FALSE, cex.lab=.8)
box()
axis(1, at=c(1950, 1960, 1970, 1980, 1990, 2000, 2010), cex.axis=.7)
axis(2, cex.axis=.7)
lines(as.numeric(dimnames(table(gwf$gwf_military, gwf$year))[[2]]), 
      table(gwf$gwf_military, gwf$year)[2,], lty=2)

plot(data5yr$year, data5yr$totalpy, 
     ylim=c(0,max(data5yr$totalpy)), type="l",
     xlim=c(1950, 2010),
     xlab="Year",
     ylab="Coups per Year (5 Year Groupings)",
     axes=FALSE, cex.lab=.8)
box()
axis(1, at=c(1950, 1960, 1970, 1980, 1990, 2000, 2010), cex.axis=.7)
axis(2, cex.axis=.7)
lines(data5yr$year, data5yr$successpy, type = "l", lty = 2)
###########################
# END CODE FOR FIGURE 1
###########################



# Requires msm packages for truncated normal distribution
library(msm)

###############################
# START CODE FOR FIGURE 2
###############################
par(mfrow=c(1,2), mar=c(3,1.5,1.5,1), mgp=c(2, .7, 0))

# Non-trucated version
curve(dnorm(x, -.3, .3), -.75, 1.5, axes=FALSE, 
      xlab="Regime Strength",
      col=rgb(.7, .7, .7))
curve(dnorm(x, .6, .3), add=TRUE)
box()
axis(1, at=c(0, 1), lty=0)
abline(v=c(0,1))
mtext("Density of Belief", side=2, line=.3)

#Truncated version
curve(dtnorm(x, -.3, .3, lower=.1), .1, 1.5, xlim=c(-.75, 1.5), axes=FALSE, 
      xlab="Regime Strength", ylab = "",
      col=rgb(.7, .7, .7))
curve(dtnorm(x, .6, .3, lower=.1), .1, 1.5, add=TRUE)
box()
axis(1, at=c(0, 1), lty=0)
abline(v=c(0,1))
abline(v=.1, lty=2)
###############################
# END CODE FOR FIGURE 2
###############################

# RHS of equilibrium condition for period 1
rhs <- function(hatT, a=1, b=1, mu0=.5){
  inside <- (a/sqrt(a + b))*(hatT - mu0) - sqrt(b/(a+b))*qnorm(hatT)
  return(pnorm(inside))
}


# Finding solutions to equilibrium condition
# only works when unique eqm
get.hatq1 <- function(a=1, b=1, mu0=.5, q=.5){
  diff <- function(x) rhs(hatT=x, a=a, b=b, mu0=mu0) - q
  root <- uniroot(diff, interval=c(0,1))
  return(root$root)
}

get.shat1 <- function(a=1, b=1, mu0=.5, q=.5){
  hatq1 <- get.hatq1(a=a, b=b, mu0=mu0, q=q)
  return(b^(-1/2)*qnorm(hatq1) + hatq1)
}


#  equilibrium condition for later periods  
bottom <- function(hatqt, hatqt1=.1, a=1, bt=1, mu0=.5){
  pnorm(sqrt(bt + a)*((bt/(bt+a)*(hatqt + qnorm(hatqt)/sqrt(bt)) 
                 + a/(bt+a)*mu0 - hatqt1)))
} 

rhst <- function(hatqt, hatqt1=.1, a=1, bt=1, mu0=.5){
  top <- (a/sqrt(a + bt))*(mu0 - hatqt) + sqrt(bt/(a+bt))*qnorm(hatqt)
  bottom <- sqrt(bt + a)*((bt/(bt+a)*(hatqt + qnorm(hatqt)/sqrt(bt)) 
                           + a/(bt+a)*mu0 - hatqt1))
  return(ifelse(hatqt <=hatqt1, 0, 1 - pnorm(top)/pnorm(bottom)))
  
}

# Example where regime surviving first round survives forever (not in published version)
par(mfrow=c(1,2), mar=c(3,3,2,1), mgp=c(2, .7, 0))
hatq1 <- get.hatq1(q=.7, mu0=0)
curve(rhs(hatT=x, mu0=0), 0, 1, axes=FALSE, n=501,
      xlab="Proposed Survival Threshold", 
      ylab="RHS of Equilibrium Condition")
abline(h=.7)
abline(v=(hatq1))
box()
axis(1, at=c(0,hatq1, 1), labels=c(0, expression(paste(hat(theta)[1])), 1))
axis(2, at=.7, expression(q[t]))
title(main="Period 1")

curve(rhst(hatqt=x, a=1, mu0=.5, bt=2, hatqt1=hatq1), 0, 1, ylim=c(0, 1), lwd=1,
      axes=FALSE, n=501,
      xlab = "Proposed Survival Threshold",
      ylab = "RHS of Equilibrium Condition")
abline(h=.7)
for (i in 2^(2:15)){
  curve(rhst(hatqt=x, a=1, mu0=.5, bt=i, hatqt1=hatq1), from=hatq1,  add=TRUE,
        col=rgb(.5, .5, .5, alpha=.7))
}
box()
curve(1-x, from=hatq1 + .003, to=1, add=TRUE, lwd=2)
axis(1, at=c(0, hatq1, 1), label=c(0, expression(hat(theta)[1]), 1))
axis(2, at=.7, label=expression(q[t]))
abline(v=hatq1)
title(main="Periods 2 to Infinity")

text(.93, .25, "Period 2", cex=.7)
text(.5, .6, "Limit", cex=.7)


# Example where no coups from periods 2 to 200 (not in published version)
par(mfrow=c(1,2), mar=c(3,3,2,1), mgp=c(2, .7, 0))
hatq1 <- get.hatq1(q=.7, mu0=.5)
curve(rhs(hatT=x, mu0=.5), 0, 1, axes=FALSE, n=501,
      xlab="Proposed Survival Threshold", 
      ylab="RHS of Equilibrium Condition")
abline(h=.7)
abline(v=(hatq1))
box()
axis(1, at=c(0,hatq1, 1), labels=c(0, expression(paste(hat(theta)[1])), 1))
axis(2, at=.7, "q")
title(main="Period 1")


# SECOND ATTACK
curve(rhst(hatqt=x, a=1, mu0=.5, bt=2, hatqt1=hatq1), 0, 1, ylim=c(0, 1),
      
      axes=FALSE, n=501,
      xlab = "Proposed Survival Threshold",
      ylab = "RHS of Equilibrium Condition")
abline(h=.7)
for (i in seq(4, 200, by=20)){
  curve(rhst(hatqt=x, a=1, mu0=.5, bt=i, hatqt1=hatq1), from=hatq1, add=TRUE,
        col=rgb(.5, .5, .5, alpha=.7))
}
curve(rhst(hatqt=x, a=1, mu0=.2, bt=200, hatqt1=hatq1), add=TRUE, n=501, lwd=2)
hatq2500 <- .29
box()
axis(1, at=c(0, hatq1, 1), 
     labels=c(0,expression(hat(theta)[1]), 1))
# mtext("*", 1, at=hatq1+.015, line=.7)
axis(2, at=.7, "q")
abline(v=hatq1)
title("Periods 2 to 200")

text(.93, .3, "Period 2", cex=.7)
text(.63, .54, "Period 200", cex=.7)


###############################
# START CODE FOR FIGURE 3
###############################
par(mfrow=c(1,2), mar=c(3,3,2,1), mgp=c(2, .7, 0))
hatq1 <- get.hatq1(q=.8, mu0=0)
hatq1.1 <- get.hatq1(q=.6, mu0=0)
curve(rhs(hatT=x, mu0=0), 0, 1, axes=FALSE, n=501,
      xlab="Proposed Survival Threshold", 
      ylab="RHS of Equilibrium Condition")
abline(h=c(.8, .6), lty=c(1,2))
abline(v=c(hatq1, hatq1.1), lty=c(1,2))
box()
axis(1, at=c(0,hatq1, hatq1.1, 1), labels=c(0, expression(paste(hat(theta)[1])),
                                            expression(paste(hat(theta)[1], "'")) ,1))
# mtext("*", 1, at=hatq1+.015, line=.7)
axis(2, at=c(.8, .6), c(expression(q[1]), expression(paste(q[1], "'"))))
title(main="Period 1")

curve(rhst(hatqt=x, a=1, mu0=0, bt=2, hatqt1=hatq1), 0, 1, ylim=c(0, 1), lwd=1,
      axes=FALSE, n=501,
      xlab = "Proposed Survival Threshold",
      ylab = "RHS of Equilibrium Condition")

curve(rhst(hatqt=x, a=1, mu0=0, bt=2, hatqt1=hatq1.1), add=TRUE, lty=2)

abline(v=c(hatq1, hatq1.1), lty=c(1,2))
axis(1, at=c(0,hatq1, hatq1.1, 1), labels=c(0, expression(paste(hat(theta)[1])),
                                            expression(paste(hat(theta)[1], "'")) ,1))
abline(h=c(.35))
axis(2, at=c(.35), 
     labels=c(expression(q[2])),
     lwd=0)
box()
title(main="Period 2")
###############################
# END CODE FOR FIGURE 3
###############################


